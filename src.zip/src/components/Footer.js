function Footer() {
    return (
        <>
        This is Footer
        </>
    )
}
export default Footer;